
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="157475" data-name="act" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">act <a href="#"  class="" onclick="shortUsers(157475 ,150869,0,2)">
                        <span  style="float:right;padding-right:16px;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">act <a href="#"  class="" onclick="shortUsers(157475 ,150869,0,2)">
                        <span  style="float:right;padding-right:16px;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>1953.27</strong></span></td>
                <td class="text-center hidden-xs"><strong>1953.27</strong></td>
                                <td class="text-center hidden-xs"><strong>240.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Lady Pin-Ups 100</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="1953.27"
                            data-player-id="157475" data-name-id="act"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="act"
                            data-player-id="157475" data-score-id="1953.27"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="157475" data-name="act" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(157475,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="150869" data-name="tun1" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">tun1 <a href="#" class="" onclick="shortUsers(150869 ,150870,157475,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(150869 ,150870,157475,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">tun1 <a href="#" class="" onclick="shortUsers(150869 ,150870,157475,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(150869 ,150870,157475,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.04</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.04</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Buffalo King</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.04"
                            data-player-id="150869" data-name-id="tun1"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="tun1"
                            data-player-id="150869" data-score-id="0.04"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="150869" data-name="tun1" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(150869,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="150870" data-name="tun2" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">tun2 <a href="#" class="" onclick="shortUsers(150870 ,90216,150869,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(150870 ,90216,150869,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">tun2 <a href="#" class="" onclick="shortUsers(150870 ,90216,150869,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(150870 ,90216,150869,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.00</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Diamond Monkey</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.00"
                            data-player-id="150870" data-name-id="tun2"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="tun2"
                            data-player-id="150870" data-score-id="0.00"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="150870" data-name="tun2" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(150870,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="90216" data-name="646464" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">646464 <a href="#" class="" onclick="shortUsers(90216 ,247983,150870,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(90216 ,247983,150870,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">646464 <a href="#" class="" onclick="shortUsers(90216 ,247983,150870,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(90216 ,247983,150870,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>199.90</strong></span></td>
                <td class="text-center hidden-xs"><strong>199.90</strong></td>
                                <td class="text-center hidden-xs"><strong>40.00</strong></td>
                				<td class="text-center hidden-xs"><strong>-</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="199.90"
                            data-player-id="90216" data-name-id="646464"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="646464"
                            data-player-id="90216" data-score-id="199.90"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="90216" data-name="646464" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(90216,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="247983" data-name="Kuzu11" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">Kuzu11 <a href="#" class="" onclick="shortUsers(247983 ,104646,90216,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(247983 ,104646,90216,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">Kuzu11 <a href="#" class="" onclick="shortUsers(247983 ,104646,90216,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(247983 ,104646,90216,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>500.00</strong></span></td>
                <td class="text-center hidden-xs"><strong>500.00</strong></td>
                                <td class="text-center hidden-xs"><strong>100.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Ultra Burn</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="500.00"
                            data-player-id="247983" data-name-id="Kuzu11"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="Kuzu11"
                            data-player-id="247983" data-score-id="500.00"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="247983" data-name="Kuzu11" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(247983,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="104646" data-name="test46" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">test46 <a href="#" class="" onclick="shortUsers(104646 ,107567,247983,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(104646 ,107567,247983,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">test46 <a href="#" class="" onclick="shortUsers(104646 ,107567,247983,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(104646 ,107567,247983,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.02</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.02</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>-</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.02"
                            data-player-id="104646" data-name-id="test46"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="test46"
                            data-player-id="104646" data-score-id="0.02"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="104646" data-name="test46" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(104646,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="107567" data-name="dimi123" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">dimi123 <a href="#" class="" onclick="shortUsers(107567 ,106410,104646,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(107567 ,106410,104646,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">dimi123 <a href="#" class="" onclick="shortUsers(107567 ,106410,104646,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(107567 ,106410,104646,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>75.69</strong></span></td>
                <td class="text-center hidden-xs"><strong>75.69</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Mayan Spirit</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="75.69"
                            data-player-id="107567" data-name-id="dimi123"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="dimi123"
                            data-player-id="107567" data-score-id="75.69"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="107567" data-name="dimi123" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(107567,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="106410" data-name="wien123" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">wien123 <a href="#" class="" onclick="shortUsers(106410 ,226008,107567,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(106410 ,226008,107567,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">wien123 <a href="#" class="" onclick="shortUsers(106410 ,226008,107567,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(106410 ,226008,107567,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.00</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Lucky Lady's Charm Deluxe</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.00"
                            data-player-id="106410" data-name-id="wien123"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="wien123"
                            data-player-id="106410" data-score-id="0.00"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="106410" data-name="wien123" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(106410,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="226008" data-name="vo-158779" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">vo-158779 <a href="#" class="" onclick="shortUsers(226008 ,108748,106410,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(226008 ,108748,106410,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">vo-158779 <a href="#" class="" onclick="shortUsers(226008 ,108748,106410,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(226008 ,108748,106410,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>5.80</strong></span></td>
                <td class="text-center hidden-xs"><strong>5.80</strong></td>
                                <td class="text-center hidden-xs"><strong>2.00</strong></td>
                				<td class="text-center hidden-xs"><strong>-</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="5.80"
                            data-player-id="226008" data-name-id="vo-158779"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="vo-158779"
                            data-player-id="226008" data-score-id="5.80"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="226008" data-name="vo-158779" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(226008,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="108748" data-name="dracula365" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">dracula365 <a href="#" class="" onclick="shortUsers(108748 ,151031,226008,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(108748 ,151031,226008,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">dracula365 <a href="#" class="" onclick="shortUsers(108748 ,151031,226008,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(108748 ,151031,226008,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.00</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Colin the Cat</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.00"
                            data-player-id="108748" data-name-id="dracula365"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="dracula365"
                            data-player-id="108748" data-score-id="0.00"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="108748" data-name="dracula365" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(108748,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="151031" data-name="Balzaretti007" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">Balzaretti <a href="#" class="" onclick="shortUsers(151031 ,158992,108748,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(151031 ,158992,108748,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">Balzaretti <a href="#" class="" onclick="shortUsers(151031 ,158992,108748,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(151031 ,158992,108748,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.01</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.01</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>Wild Shark</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.01"
                            data-player-id="151031" data-name-id="Balzaretti007"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="Balzaretti007"
                            data-player-id="151031" data-score-id="0.01"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="151031" data-name="Balzaretti007" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(151031,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="158992" data-name="tvjackpot_346194" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">tvjackpot_ <a href="#" class="" onclick="shortUsers(158992 ,34704,151031,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(158992 ,34704,151031,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">tvjackpot_ <a href="#" class="" onclick="shortUsers(158992 ,34704,151031,1)">
                <span style="float:right; " class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a>
                <a href="#" class="" onclick="shortUsers(158992 ,34704,151031,2)">
                        <span  style="float:right;" class="glyphicon glyphicon-arrow-down hidden-xs" aria-hidden="true"></span></a> : <strong>0.00</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>-</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.00"
                            data-player-id="158992" data-name-id="tvjackpot_346194"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="tvjackpot_346194"
                            data-player-id="158992" data-score-id="0.00"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="158992" data-name="tvjackpot_346194" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(158992,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            
            <tr>
                <td class="text-center"><span class="hidden-xs"> <a href="#" data-id="34704" data-name="Milano1" class="changeplayername" data-toggle="modal" data-target="#ChangeNameModal"><strong style="color:black;">Milano1 <a href="#" class="" onclick="shortUsers(34704 ,0,158992,1)">
                        <span  style="float:right; padding-right:16px" class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a></strong></a> </span> <span
                        class="visible-xs">Milano1 <a href="#" class="" onclick="shortUsers(34704 ,0,158992,1)">
                        <span  style="float:right; padding-right:16px" class="glyphicon glyphicon-arrow-up hidden-xs" aria-hidden="true"></span></a> : <strong>0.01</strong></span></td>
                <td class="text-center hidden-xs"><strong>0.01</strong></td>
                                <td class="text-center hidden-xs"><strong>0.00</strong></td>
                				<td class="text-center hidden-xs"><strong>-</strong></td>
                                <td class="text-center " style="padding: 2px 0px;">
                    <button style="width: 45px; height: 35px;" type="button" 
                            data-score-id="0.01"
                            data-player-id="34704" data-name-id="Milano1"
                            data-toggle="modal" data-target=".inmodal"
                            class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus-sign"
                                                                 aria-hidden="true"></span></button>
                    <button style="width: 45px; height: 35px;" type="button" data-toggle="modal" data-target=".outmodal"
                            data-name-id="Milano1"
                            data-player-id="34704" data-score-id="0.01"
                             class="btn btn-danger btn-xs "><span
                            class="glyphicon glyphicon-minus-sign " aria-hidden="true"></span></button>
                </td>
                                                <td class="text-center hidden-xs" style="padding: 2px 0px;">
                    <button id="" style="width: 45px; height: 35px;" data-id="34704" data-name="Milano1" data-target=".playerProfile"
                            data-toggle="modal" class="success btn btn-warning playeridchangepass"><span
                            class="glyphicon glyphicon-edit"></span></button>
                </td>
                                                                    <td class="text-center" style="padding: 2px 0px;">
                        <button id="alarmbutton" style="width: 45px; height: 35px;"
                                onclick="alarmOn(34704,1)"
                                class="success btn btn-success"><span class="glyphicon glyphicon-ok-circle"></span>
                        </button>
                    </td>
                                            </tr>
            [["157475","1","act","195327","24000","0","0","237"],["150869","1","tun1","4","0","0","0","7111"],["150870","1","tun2","0","0","0","0","147"],["90216","1","646464","19990","4000","0","0","0"],["247983","1","Kuzu11","50000","10000","0","0","7120"],["104646","1","test46","2","0","0","0","0"],["107567","1","dimi123","7569","0","0","0","2016"],["106410","1","wien123","0","0","0","0","1007"],["226008","1","vo-158779","580","200","0","0","0"],["108748","1","dracula365","0","0","0","0","4065"],["151031","1","Balzaretti007","1","0","0","0","126"],["158992","1","tvjackpot_346194","0","0","0","0","0"],["34704","1","Milano1","1","0","0","2","0"]]